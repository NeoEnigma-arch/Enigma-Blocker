/**
 * Enigma Blocker – Content script
 * Cosmetic filtering + element picker
 */

(function () {
  "use strict";

  if (window.__enigmaBlockerContent) return;
  window.__enigmaBlockerContent = true;

  let styleEl = null;
  let pickerActive = false;
  let hoverEl = null;
  let overlay = null;

  function hostname() {
    try {
      return location.hostname.toLowerCase();
    } catch (_) {
      return "";
    }
  }

  function applySelectors(selectors) {
    if (!selectors || !selectors.length) return;

    // batch to avoid huge style sheets
    const css = selectors
      .map((s) => {
        try {
          // basic sanity
          if (!s || s.length > 500) return "";
          return `${s}{display:none!important;visibility:hidden!important;height:0!important;max-height:0!important;overflow:hidden!important;}`;
        } catch (_) {
          return "";
        }
      })
      .filter(Boolean)
      .join("\n");

    if (!css) return;

    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "enigma-blocker-cosmetic";
      styleEl.setAttribute("data-enigma", "1");
      (document.documentElement || document.head || document).appendChild(styleEl);
    }
    styleEl.textContent = css;
  }

  async function loadCosmetic() {
    try {
      const res = await browser.runtime.sendMessage({
        type: "getCosmetic",
        hostname: hostname(),
      });
      if (res && res.selectors) applySelectors(res.selectors);
    } catch (_) {
      /* extension reloading */
    }
  }

  // ── Element picker ─────────────────────────────────────

  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "enigma-picker-overlay";
    Object.assign(overlay.style, {
      position: "fixed",
      pointerEvents: "none",
      zIndex: "2147483646",
      border: "2px solid #00e676",
      background: "rgba(0,230,118,0.12)",
      boxShadow: "0 0 0 1px rgba(0,0,0,0.4)",
      transition: "all 0.05s linear",
      display: "none",
    });
    document.documentElement.appendChild(overlay);

    const hint = document.createElement("div");
    hint.id = "enigma-picker-hint";
    Object.assign(hint.style, {
      position: "fixed",
      top: "12px",
      left: "50%",
      transform: "translateX(-50%)",
      zIndex: "2147483647",
      background: "#0a0e14",
      color: "#00e676",
      border: "1px solid #00e676",
      padding: "8px 14px",
      fontFamily: "ui-monospace, Consolas, monospace",
      fontSize: "12px",
      borderRadius: "6px",
      display: "none",
      boxShadow: "0 4px 24px rgba(0,0,0,0.5)",
    });
    hint.textContent = "Enigma Picker: Klick = ausblenden · Esc = abbrechen";
    document.documentElement.appendChild(hint);
    return overlay;
  }

  function buildSelector(el) {
    if (!el || el === document.documentElement || el === document.body) {
      return null;
    }
    if (el.id && /^[a-zA-Z][\w-]*$/.test(el.id)) {
      return `#${el.id}`;
    }
    const classes = (el.className && typeof el.className === "string"
      ? el.className
      : ""
    )
      .trim()
      .split(/\s+/)
      .filter((c) => c && c.length < 40 && !/^[0-9]/.test(c))
      .slice(0, 3);
    if (classes.length) {
      return el.tagName.toLowerCase() + classes.map((c) => `.${CSS.escape(c)}`).join("");
    }
    return el.tagName.toLowerCase();
  }

  function onPickerMove(e) {
    if (!pickerActive) return;
    const el = document.elementFromPoint(e.clientX, e.clientY);
    if (!el || el === overlay || el.id === "enigma-picker-hint") return;
    hoverEl = el;
    const r = el.getBoundingClientRect();
    const ov = ensureOverlay();
    ov.style.display = "block";
    ov.style.left = r.left + "px";
    ov.style.top = r.top + "px";
    ov.style.width = r.width + "px";
    ov.style.height = r.height + "px";
  }

  async function onPickerClick(e) {
    if (!pickerActive) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    const el = hoverEl || e.target;
    const selector = buildSelector(el);
    stopPicker();
    if (!selector) return;

    // hide immediately
    try {
      el.style.setProperty("display", "none", "important");
    } catch (_) {}

    // persist as custom cosmetic filter for this host
    try {
      const host = hostname();
      const line = `${host}##${selector}`;
      const res = await browser.runtime.sendMessage({ type: "getCustomFilters" });
      const prev = (res && res.customFilters) || "";
      const next = prev ? prev + "\n" + line : line;
      await browser.runtime.sendMessage({
        type: "updateSettings",
        settings: { customFilters: next },
        reloadFilters: true,
      });
      // re-apply
      loadCosmetic();
    } catch (err) {
      console.warn("[Enigma] picker save failed", err);
    }
  }

  function onPickerKey(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      stopPicker();
    }
  }

  function startPicker() {
    if (pickerActive) return;
    pickerActive = true;
    ensureOverlay();
    document.getElementById("enigma-picker-hint").style.display = "block";
    document.addEventListener("mousemove", onPickerMove, true);
    document.addEventListener("click", onPickerClick, true);
    document.addEventListener("keydown", onPickerKey, true);
  }

  function stopPicker() {
    pickerActive = false;
    hoverEl = null;
    document.removeEventListener("mousemove", onPickerMove, true);
    document.removeEventListener("click", onPickerClick, true);
    document.removeEventListener("keydown", onPickerKey, true);
    if (overlay) overlay.style.display = "none";
    const hint = document.getElementById("enigma-picker-hint");
    if (hint) hint.style.display = "none";
  }

  browser.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "startPicker") {
      startPicker();
      return Promise.resolve({ ok: true });
    }
    if (msg && msg.type === "reloadCosmetic") {
      loadCosmetic();
      return Promise.resolve({ ok: true });
    }
  });

  // early apply
  loadCosmetic();

  // SPA re-apply on navigation-ish
  let lastHref = location.href;
  setInterval(() => {
    if (location.href !== lastHref) {
      lastHref = location.href;
      loadCosmetic();
    }
  }, 1500);
})();
