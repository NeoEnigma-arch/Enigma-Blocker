/**
 * Enigma Blocker – YouTube Ad Killer (content-script world)
 * - Injects page hook (CSP-safe via extension URL)
 * - Skips/fast-forwards in-player ads
 * - Hides feed / overlay ad UI
 */
(function () {
  "use strict";

  if (window.__enigmaYoutube) return;
  window.__enigmaYoutube = true;

  const HOST = location.hostname || "";
  if (!/(^|\.)youtube\.com$|(^|\.)youtube-nocookie\.com$|(^|\.)youtu\.be$/.test(HOST)) {
    return;
  }

  let allowed = true;

  browser.runtime
    .sendMessage({ type: "getState" })
    .then((state) => {
      if (!state || !state.settings) return;
      if (!state.settings.enabled) allowed = false;
      const wl = state.settings.whitelist || [];
      if (wl.some((w) => HOST === w || HOST.endsWith("." + w))) allowed = false;
    })
    .catch(() => {});

  /* display:none + collapsen: Grid/Flex-Lücken der Ad-Wrapper schließen */
  const COLLAPSE = `
  display: none !important;
  visibility: hidden !important;
  height: 0 !important;
  max-height: 0 !important;
  min-height: 0 !important;
  max-width: 0 !important;
  width: 0 !important;
  flex: 0 0 0 !important;
  flex-grow: 0 !important;
  flex-basis: 0 !important;
  grid-template-rows: 0fr !important;
  overflow: hidden !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  opacity: 0 !important;
  pointer-events: none !important;
  position: absolute !important;
  left: -99999px !important;
  z-index: -1 !important;
`;

  const CSS = `
/* Player-Overlays */
.ytp-ad-image-overlay,
.ytp-ad-overlay-container,
.ytp-ad-overlay-slot,
.ytp-ad-text-overlay,
.ytp-ad-message-container,
.ytp-ad-feedback-dialog-container,
.ytp-ad-action-interstitial,
.ytp-ad-action-interstitial-slot,
.ytp-ad-player-overlay-instream-info,
.ytp-ad-info-dialog-container,
.ytp-ad-progress-list,
.video-ads,
.video-ads .ytp-ad-overlay-slot,
/* Ad-Renderer */
ytd-ad-slot-renderer,
ytd-banner-promo-renderer,
ytd-statement-banner-renderer,
ytd-in-feed-ad-layout-renderer,
ytd-promoted-sparkles-web-renderer,
ytd-promoted-video-renderer,
ytd-compact-promoted-video-renderer,
ytd-compact-promoted-item-renderer,
ytd-display-ad-renderer,
ytd-action-companion-ad-renderer,
ytd-player-legacy-desktop-watch-ads-renderer,
ytd-search-pyv-renderer,
ytd-merch-shelf-renderer,
ytd-mealbar-promo-renderer,
yt-mealbar-promo-renderer,
ytd-prime-time-promo-renderer,
ytd-brand-video-shelf-renderer,
ytd-brand-video-singleton-renderer,
ytd-promoted-sparkles-text-search-renderer,
ytd-ad-hover-text-button-renderer,
ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"],
ytd-engagement-panel-section-list-renderer[target-id*="ads"],
/* Eltern-Shells: verhindern leere Kacheln im Feed */
ytd-rich-item-renderer:has(ytd-ad-slot-renderer),
ytd-rich-item-renderer:has(ytd-display-ad-renderer),
ytd-rich-item-renderer:has(ytd-in-feed-ad-layout-renderer),
ytd-rich-item-renderer:has(ytd-banner-promo-renderer),
ytd-rich-item-renderer:has(ytd-promoted-sparkles-web-renderer),
ytd-rich-item-renderer:has(ytd-promoted-video-renderer),
ytd-rich-item-renderer:has([is-ad]),
ytd-rich-item-renderer[is-ad],
ytd-rich-item-renderer[is-slim-media]:has(ytd-ad-slot-renderer),
ytd-rich-section-renderer:has(ytd-ad-slot-renderer),
ytd-rich-section-renderer:has(ytd-display-ad-renderer),
ytd-rich-section-renderer:has(ytd-banner-promo-renderer),
ytd-rich-section-renderer:has(ytd-statement-banner-renderer),
ytd-item-section-renderer:has(ytd-ad-slot-renderer),
ytd-item-section-renderer:has(ytd-in-feed-ad-layout-renderer),
ytd-item-section-renderer:has(ytd-search-pyv-renderer),
ytd-item-section-renderer:has(ytd-promoted-sparkles-text-search-renderer),
ytd-reel-shelf-renderer:has(ytd-ad-slot-renderer),
ytd-filmstrip-renderer:has(ytd-ad-slot-renderer),
ytd-watch-next-secondary-results-renderer ytd-ad-slot-renderer,
ytd-watch-next-secondary-results-renderer ytd-compact-promoted-video-renderer,
ytd-watch-next-secondary-results-renderer ytd-compact-promoted-item-renderer,
#masthead-ad,
#player-ads,
#offer-module,
#panels ytd-engagement-panel-section-list-renderer[target-id*="ad"],
.ytd-video-masthead-ad-v3-renderer,
ytd-video-masthead-ad-v3-renderer,
ytd-video-masthead-ad-primary-video-renderer,
.ytd-primetime-promo-renderer,
ytm-ad-slot-renderer,
ytm-companion-ad-renderer,
ytm-promoted-sparkles-web-renderer,
ytm-in-feed-ad-layout-renderer,
ad-slot-renderer,
/* leere Markierungen vom DOM-Cleanup */
[data-enigma-ad-slot="1"] {
  ${COLLAPSE}
}
`;

  function injectStyle() {
    if (document.getElementById("enigma-yt-css")) return;
    const s = document.createElement("style");
    s.id = "enigma-yt-css";
    s.textContent = CSS;
    (document.documentElement || document.head || document).appendChild(s);
  }

  /**
   * Inject page script. Prefer extension URL (works with YT CSP in Firefox).
   * Fallback: Firefox wrappedJSObject hooks + inline script.
   */
  function injectPageHook() {
    if (document.documentElement && document.documentElement.dataset.enigmaYtHook === "1") {
      return;
    }

    // 1) Extension script tag (web_accessible_resources)
    try {
      const s = document.createElement("script");
      s.id = "enigma-yt-page-hook";
      s.src = browser.runtime.getURL("youtube-page.js");
      s.async = false;
      s.onload = function () {
        s.remove();
      };
      (document.documentElement || document.head).appendChild(s);
      if (document.documentElement) document.documentElement.dataset.enigmaYtHook = "1";
      return;
    } catch (e) {
      console.warn("[Enigma YT] script src inject failed", e);
    }

    // 2) Firefox: patch page fetch via Xray unwrap
    try {
      if (typeof wrappedJSObject !== "undefined" || window.wrappedJSObject) {
        const win = window.wrappedJSObject || wrappedJSObject;
        installWrappedHooks(win);
        if (document.documentElement) document.documentElement.dataset.enigmaYtHook = "1";
      }
    } catch (e) {
      console.warn("[Enigma YT] wrappedJSObject failed", e);
    }
  }

  function installWrappedHooks(win) {
    if (!win || win.__enigmaYtPageHook) return;
    // Load logic by evaluating page file text is heavy; call same nuke via exportFunction
    // Simplest path: fetch the page script and eval in page
    try {
      const xhr = new XMLHttpRequest();
      xhr.open("GET", browser.runtime.getURL("youtube-page.js"), false);
      xhr.send();
      if (xhr.status === 200 || xhr.responseText) {
        win.eval(xhr.responseText);
      }
    } catch (_) {
      /* eval may be blocked */
    }
  }

  const SKIP_SELECTORS = [
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-skip-ad-button",
    ".ytp-ad-skip-button-container button",
    ".ytp-ad-skip-button-slot button",
    "button.ytp-ad-skip-button-modern",
    ".ytp-ad-overlay-close-button",
    ".ytp-ad-overlay-close-container button",
    ".ytp-ad-skip-button-text",
    ".videoAdUiSkipButton",
    ".ytp-ad-skip-button-container .ytp-button",
    "button.ytp-ad-skip-button",
    "yt-button-shape.ytp-ad-skip-button-modern button",
    ".ytp-skip-ad-button__text",
  ];

  function isInsideComposer(el) {
    // Kommentar-, Community-Post- und Chat-Eingaben nie anfassen
    return !!(
      el &&
      el.closest &&
      el.closest(
        [
          "#contenteditable-root",
          "#contenteditable-textarea",
          "ytd-commentbox",
          "ytd-comment-simplebox-renderer",
          "ytd-comment-dialog-renderer",
          "ytd-backstage-post-dialog-renderer",
          "ytd-engagement-panel-section-list-renderer",
          "yt-live-chat-text-input-field-renderer",
          "yt-live-chat-message-input-renderer",
          "#placeholder-area",
          "#simplebox-placeholder",
          "[contenteditable='true']",
          "tp-yt-paper-input",
          "tp-yt-paper-textarea",
        ].join(",")
      )
    );
  }

  function clickSkips() {
    // Nur echte Ad-Skip-Buttons (feste Selektoren) – kein generisches
    // Text-Matching auf alle Buttons (das killt u. a. Dialoge/Posts).
    for (const sel of SKIP_SELECTORS) {
      let nodes;
      try {
        nodes = document.querySelectorAll(sel);
      } catch (_) {
        continue;
      }
      for (const n of nodes) {
        if (isInsideComposer(n)) continue;
        // nur im Player-Ad-Kontext
        const inAd =
          n.closest(".ytp-ad-module, .video-ads, .ytp-ad-player-overlay, .html5-video-player.ad-showing") ||
          n.className && String(n.className).includes("ytp-ad");
        if (!inAd && !String(sel).includes("ytp-ad") && !String(sel).includes("skip-ad")) {
          continue;
        }
        try {
          n.click();
        } catch (_) {}
      }
    }
  }

  function getPlayer() {
    return (
      document.querySelector("#movie_player") ||
      document.querySelector(".html5-video-player") ||
      document.querySelector("#ytd-player .html5-video-player")
    );
  }

  function getVideo(player) {
    if (player) {
      const v = player.querySelector("video");
      if (v) return v;
    }
    return document.querySelector("video.html5-main-video") || document.querySelector("video");
  }

  function isAdShowing(player) {
    if (
      player &&
      (player.classList.contains("ad-showing") || player.classList.contains("ad-interrupting"))
    ) {
      return true;
    }
    return !!document.querySelector(
      ".html5-video-player.ad-showing, .html5-video-player.ad-interrupting"
    );
  }

  let lastSkipReport = 0;
  let forcedRate = false;
  let lastCollapse = 0;

  // Ad-Nodes selbst (werden entfernt)
  const AD_NODE_SELECTORS = [
    "ytd-ad-slot-renderer",
    "ytd-in-feed-ad-layout-renderer",
    "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer",
    "ytd-promoted-video-renderer",
    "ytd-compact-promoted-video-renderer",
    "ytd-compact-promoted-item-renderer",
    "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer",
    "ytd-mealbar-promo-renderer",
    "yt-mealbar-promo-renderer",
    "ytd-action-companion-ad-renderer",
    "ytd-player-legacy-desktop-watch-ads-renderer",
    "ytd-search-pyv-renderer",
    "ytd-merch-shelf-renderer",
    "ytd-prime-time-promo-renderer",
    "ytd-brand-video-shelf-renderer",
    "ytd-brand-video-singleton-renderer",
    "ytd-promoted-sparkles-text-search-renderer",
    "ytd-video-masthead-ad-v3-renderer",
    "ytd-video-masthead-ad-primary-video-renderer",
    "#masthead-ad",
    "#player-ads",
    "#offer-module",
    "ytm-ad-slot-renderer",
    "ytm-companion-ad-renderer",
    "ytm-promoted-sparkles-web-renderer",
    "ytm-in-feed-ad-layout-renderer",
    "ad-slot-renderer",
  ].join(",");

  // Eltern-Wrapper, die als leere Fläche bleiben würden
  const AD_SHELL_TAGS = new Set([
    "YTD-RICH-ITEM-RENDERER",
    "YTD-RICH-SECTION-RENDERER",
    "YTD-ITEM-SECTION-RENDERER",
    "YTD-REEL-SHELF-RENDERER",
    "YTD-FILMSTRIP-RENDERER",
    "YTD-SHELF-RENDERER",
  ]);

  function markAndHide(el) {
    if (!el || el.nodeType !== 1) return;
    try {
      el.setAttribute("data-enigma-ad-slot", "1");
      el.style.setProperty("display", "none", "important");
      el.style.setProperty("height", "0", "important");
      el.style.setProperty("min-height", "0", "important");
      el.style.setProperty("margin", "0", "important");
      el.style.setProperty("padding", "0", "important");
      el.style.setProperty("overflow", "hidden", "important");
    } catch (_) {}
  }

  function removeNode(el) {
    if (!el || !el.parentNode) return;
    try {
      el.remove();
    } catch (_) {
      try {
        el.parentNode.removeChild(el);
      } catch (__) {}
    }
  }

  /**
   * Entfernt Ad-Nodes und kollabiert leere Eltern-Shells
   * (Home-Feed, Search, Sidebar, Watch-Secondary).
   */
  function collapseEmptyAdSlots() {
    if (!allowed) return;
    const now = Date.now();
    // throttle: max alle ~400ms (Feed ändert sich oft)
    if (now - lastCollapse < 400) return;
    lastCollapse = now;

    const roots = [];
    const push = (sel) => {
      try {
        document.querySelectorAll(sel).forEach((n) => roots.push(n));
      } catch (_) {}
    };
    // ganze Seite scannen (nicht nur Player) – aber Composer unangetastet
    push(AD_NODE_SELECTORS);

    // is-ad Attribute (neue YT-Varianten)
    try {
      document
        .querySelectorAll(
          "ytd-rich-item-renderer[is-ad], ytd-rich-item-renderer[is-slim-media][is-ad], ytd-ad-slot-renderer, [is-ad='true']"
        )
        .forEach((n) => roots.push(n));
    } catch (_) {}

    // "Anzeige" / "Ad" / "Sponsored" Badges → nächstgelegene Kachel
    try {
      document
        .querySelectorAll(
          "ytd-badge-supported-renderer, .badge-style-type-ad, .yt-badge-shape--ad, [aria-label='Anzeige'], [aria-label='Ad'], [aria-label='Sponsored']"
        )
        .forEach((badge) => {
          const t = (badge.textContent || "").trim().toLowerCase();
          const al = (badge.getAttribute("aria-label") || "").toLowerCase();
          const isAdBadge =
            t === "anzeige" ||
            t === "ad" ||
            t === "ads" ||
            t === "sponsored" ||
            t === "werbung" ||
            al === "anzeige" ||
            al === "ad" ||
            al === "sponsored" ||
            (badge.className && String(badge.className).includes("ad"));
          if (!isAdBadge) return;
          if (isInsideComposer(badge)) return;
          const shell =
            badge.closest(
              "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-item-section-renderer, ytd-compact-video-renderer, ytd-video-renderer, ytd-compact-promoted-video-renderer, ytd-ad-slot-renderer"
            ) || badge;
          roots.push(shell);
        });
    } catch (_) {}

    const seen = new Set();
    for (const el of roots) {
      if (!el || seen.has(el)) continue;
      seen.add(el);
      if (isInsideComposer(el)) continue;

      // Eltern-Shell der Kachel holen (leere Fläche = Wrapper, nicht nur innerer Renderer)
      let target = el;
      let p = el.parentElement;
      let hops = 0;
      while (p && hops < 6) {
        if (AD_SHELL_TAGS.has(p.tagName)) {
          // Shell nur opfern, wenn sie im Wesentlichen die Ad ist
          const hasRealVideo =
            p.querySelector(
              "ytd-rich-grid-media, ytd-rich-grid-slim-media, ytd-video-renderer, ytd-compact-video-renderer, ytd-playlist-renderer, ytd-radio-renderer, ytd-grid-video-renderer"
            ) &&
            !p.querySelector(
              "ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-display-ad-renderer, ytd-promoted-sparkles-web-renderer"
            );
          // Wenn Shell nur Ad enthält (oder is-ad), ganze Shell entfernen
          if (
            p.hasAttribute("is-ad") ||
            p.querySelector(
              "ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-display-ad-renderer, ytd-promoted-sparkles-web-renderer, ytd-banner-promo-renderer, ytd-promoted-video-renderer"
            )
          ) {
            // Prüfen: gibt es nicht-Ad Hauptinhalt neben der Ad?
            const kids = p.children ? Array.from(p.children) : [];
            const onlyAds =
              kids.length === 0 ||
              kids.every((k) => {
                const tag = k.tagName || "";
                return (
                  /AD|PROMOTED|PROMO|MERCH|MEALBAR|BANNER-PROMO|STATEMENT-BANNER|SPARKLES/i.test(
                    tag
                  ) ||
                  k.hasAttribute("is-ad") ||
                  k.querySelector(
                    "ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-display-ad-renderer"
                  )
                );
              });
            if (onlyAds || p.hasAttribute("is-ad") || !hasRealVideo) {
              target = p;
            }
          }
          break;
        }
        p = p.parentElement;
        hops++;
      }

      markAndHide(target);
      removeNode(target);
    }

    // Rest-Lücken: leere rich-items ohne sichtbaren Inhalt
    try {
      document
        .querySelectorAll(
          "ytd-rich-item-renderer, ytd-rich-section-renderer, ytd-item-section-renderer"
        )
        .forEach((shell) => {
          if (isInsideComposer(shell)) return;
          if (shell.getAttribute("data-enigma-ad-slot") === "1") {
            removeNode(shell);
            return;
          }
          // Shell die nur versteckte Ads hatte und jetzt leer/winzig ist
          const text = (shell.textContent || "").replace(/\s+/g, " ").trim();
          const hasMedia = shell.querySelector(
            "ytd-thumbnail, img, video, ytd-rich-grid-media, ytd-rich-grid-slim-media, ytd-playlist-thumbnail"
          );
          const hasAdRemnant = shell.querySelector(
            "ytd-ad-slot-renderer, ytd-display-ad-renderer, [data-enigma-ad-slot]"
          );
          if (hasAdRemnant && !hasMedia) {
            markAndHide(shell);
            removeNode(shell);
            return;
          }
          // typische leere Ad-Kachel: "Anzeige" ohne Thumbnail
          if (
            !hasMedia &&
            text.length < 40 &&
            /^(anzeige|ad|ads|sponsored|werbung)$/i.test(text)
          ) {
            markAndHide(shell);
            removeNode(shell);
          }
        });
    } catch (_) {}
  }

  function killAd() {
    if (!allowed) return;

    const player = getPlayer();
    const video = getVideo(player);
    const ad = isAdShowing(player);

    clickSkips();

    if (ad && video) {
      try {
        video.muted = true;
        if (Number.isFinite(video.duration) && video.duration > 0 && video.duration < 180) {
          if (video.currentTime < video.duration - 0.2) {
            video.currentTime = Math.max(0, video.duration - 0.05);
          }
        } else {
          video.playbackRate = 16;
          forcedRate = true;
        }
      } catch (_) {}

      try {
        if (player) {
          if (typeof player.mute === "function") player.mute();
          if (typeof player.getCurrentTime === "function" && typeof player.seekTo === "function") {
            const dur =
              typeof player.getDuration === "function" ? player.getDuration() : video.duration;
            if (dur && dur > 0 && dur < 180) player.seekTo(dur, true);
          }
        }
      } catch (_) {}

      const now = Date.now();
      if (now - lastSkipReport > 2500) {
        lastSkipReport = now;
        browser.runtime.sendMessage({ type: "reportBlocked" }).catch(() => {});
      }
    } else if (video && forcedRate) {
      try {
        video.playbackRate = 1;
        forcedRate = false;
      } catch (_) {}
    }

    collapseEmptyAdSlots();
  }

  function onNavigate() {
    injectStyle();
    injectPageHook();
    setTimeout(killAd, 50);
    setTimeout(killAd, 400);
    setTimeout(killAd, 1200);
  }

  injectStyle();
  injectPageHook();

  // Player-Ads + Feed-Slots
  setInterval(killAd, 700);

  let moScheduled = false;
  const mo = new MutationObserver(() => {
    if (moScheduled) return;
    moScheduled = true;
    setTimeout(() => {
      moScheduled = false;
      const ae = document.activeElement;
      if (ae && isInsideComposer(ae)) return;
      killAd();
    }, 120);
  });

  function startObserver() {
    if (!document.documentElement) {
      setTimeout(startObserver, 20);
      return;
    }
    // Player + Feed/Sidebar (leere Ad-Flächen), nicht deep in Comments
    const roots = [
      document.querySelector("#movie_player"),
      document.querySelector("ytd-player"),
      document.querySelector("#player"),
      document.querySelector("#content"),
      document.querySelector("#page-manager"),
      document.querySelector("ytd-browse"),
      document.querySelector("ytd-search"),
      document.querySelector("ytd-watch-flexy"),
      document.querySelector("#secondary"),
      document.querySelector("#primary"),
      document.querySelector("ytd-rich-grid-renderer"),
      document.documentElement,
    ].filter(Boolean);

    const seen = new Set();
    for (const root of roots) {
      if (seen.has(root)) continue;
      seen.add(root);
      try {
        mo.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["class", "is-ad", "hidden"],
        });
      } catch (_) {}
    }
  }
  startObserver();
  // nach SPA-Navigation neue Roots hängen
  setTimeout(startObserver, 2000);

  document.addEventListener("yt-navigate-finish", onNavigate, true);
  document.addEventListener("yt-page-data-updated", onNavigate, true);
  window.addEventListener("yt-navigate-finish", onNavigate, true);

  const _ps = history.pushState;
  history.pushState = function () {
    const r = _ps.apply(this, arguments);
    setTimeout(onNavigate, 50);
    return r;
  };
  window.addEventListener("popstate", () => setTimeout(onNavigate, 50));
})();
