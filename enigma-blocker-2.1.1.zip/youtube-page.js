/**
 * Runs in PAGE context (injected as web_accessible script).
 * Strips ad payloads from YouTube Innertube / player bootstrap.
 */
(function () {
  if (window.__enigmaYtPageHook) return;
  window.__enigmaYtPageHook = true;

  const KILL = new Set([
    "adPlacements",
    "adSlots",
    "playerAds",
    "adBreakHeartbeatParams",
    "adBreakServiceMessage",
    "adPlacementCommands",
    "adSafetyReason",
    "adsConfig",
    "adPlacementConfig",
    "adClients",
    "adParams",
    "adBreaks",
    "adNextResponseParams",
    "serializedAdServingDataEntry",
    "playerSlotsAdClientParams",
    "adPlaceholders",
    "adSlotMetadata",
    "adReasons",
  ]);

  function isAdItem(item) {
    if (!item || typeof item !== "object") return false;
    return !!(
      item.adSlotRenderer ||
      item.adPlacementRenderer ||
      item.instreamVideoAdRenderer ||
      item.fulfillmentContentReplacementAdSlotRenderer ||
      item.bannerPromoRenderer ||
      item.promotedSparklesTextSearchRenderer ||
      item.promotedSparklesWebRenderer ||
      item.displayAdRenderer ||
      item.inFeedAdLayoutRenderer ||
      item.adBreakServiceRenderer
    );
  }

  // Schlüssel, die wir in Responses NIEMALS anfassen (Posts/Kommentare/UI)
  const SAFE_SKIP = new Set([
    "contents",
    "frameworkUpdates",
    "comments",
    "comment",
    "commentEntityPayload",
    "commentRenderer",
    "commentThreadRenderer",
    "commentRepliesRenderer",
    "createCommentParams",
    "createReplyParams",
    "engagementPanels",
    "backstagePostThreadRenderer",
    "backstagePostRenderer",
    "liveChatRenderer",
    "liveChatContinuation",
    "conversationBar",
    "header",
    "metadata",
    "microformat",
    "videoDetails",
    "streamingData",
    "playbackTracking",
    "captions",
    "storyboards",
    "attestation",
    "messages",
    "actions",
    "responseContext",
  ]);

  function nukeAds(obj, depth) {
    if (!obj || typeof obj !== "object" || depth > 10) return obj;

    if (Array.isArray(obj)) {
      for (let i = obj.length - 1; i >= 0; i--) {
        const item = obj[i];
        if (isAdItem(item)) {
          obj.splice(i, 1);
          continue;
        }
        if (item && typeof item === "object") nukeAds(item, depth + 1);
      }
      return obj;
    }

    for (const k of KILL) {
      if (k in obj) {
        if (Array.isArray(obj[k])) obj[k] = [];
        else if (obj[k] && typeof obj[k] === "object") obj[k] = {};
        else delete obj[k];
      }
    }

    if (obj.adPlacementRenderer) delete obj.adPlacementRenderer;
    if (obj.adSlotRenderer) delete obj.adSlotRenderer;
    if (obj.instreamVideoAdRenderer) delete obj.instreamVideoAdRenderer;
    if (obj.playerResponse) nukeAds(obj.playerResponse, depth + 1);

    for (const key of Object.keys(obj)) {
      if (SAFE_SKIP.has(key) || KILL.has(key)) continue;
      // keine Kommentar-/Post-Bäume durchlaufen
      if (/comment|backstage|liveChat|engagement|conversation/i.test(key)) continue;
      const v = obj[key];
      if (v && typeof v === "object") nukeAds(v, depth + 1);
    }
    return obj;
  }

  function cleanText(text) {
    try {
      const data = JSON.parse(text);
      nukeAds(data, 0);
      return JSON.stringify(data);
    } catch (_) {
      return text;
    }
  }

  /**
   * Nur Player-Ad-Payloads anfassen.
   * NICHT /next, /comment, /browse, /backstage usw. – sonst brechen
   * Kommentare, Community-Posts und Interaktionen.
   */
  function isPlayerUrl(url) {
    if (!url) return false;
    const u = String(url);
    // /player/ad_break und reines /player – aber nicht player/.../andere Dinge unnötig
    if (u.includes("get_video_info")) return true;
    if (u.includes("/youtubei/v1/player/ad_break")) return true;
    // exakt player-Endpoint (Query-String erlaubt), keine Unterpfade wie comment
    if (/\/youtubei\/v1\/player(?:\?|$)/.test(u)) return true;
    return false;
  }

  const origFetch = window.fetch;
  window.fetch = function (input) {
    const url = typeof input === "string" ? input : input && input.url;
    const p = origFetch.apply(this, arguments);
    if (!isPlayerUrl(url)) return p;
    return p.then(function (res) {
      if (!res || !res.ok) return res;
      return res
        .clone()
        .text()
        .then(function (text) {
          return new Response(cleanText(text), {
            status: res.status,
            statusText: res.statusText,
            headers: res.headers,
          });
        })
        .catch(function () {
          return res;
        });
    });
  };

  const origOpen = XMLHttpRequest.prototype.open;
  const origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (method, url) {
    this.__enigmaUrl = url;
    return origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function () {
    if (this.__enigmaUrl && isPlayerUrl(String(this.__enigmaUrl))) {
      this.addEventListener("readystatechange", function () {
        if (this.readyState !== 4) return;
        try {
          const cleaned = cleanText(this.responseText);
          Object.defineProperty(this, "responseText", { get: () => cleaned });
          Object.defineProperty(this, "response", { get: () => cleaned });
        } catch (_) {}
      });
    }
    return origSend.apply(this, arguments);
  };

  function cleanInitial() {
    // Nur Player-Response – ytInitialData enthält Kommentare/Posts/UI
    try {
      if (window.ytInitialPlayerResponse) nukeAds(window.ytInitialPlayerResponse, 0);
    } catch (_) {}
  }

  cleanInitial();
  [0, 200, 800, 2000].forEach((t) => setTimeout(cleanInitial, t));

  try {
    let _pr = window.ytInitialPlayerResponse;
    Object.defineProperty(window, "ytInitialPlayerResponse", {
      configurable: true,
      enumerable: true,
      get() {
        return _pr;
      },
      set(v) {
        _pr = nukeAds(v, 0) || v;
      },
    });
    if (_pr) _pr = nukeAds(_pr, 0);
  } catch (_) {}

  // ytInitialData absichtlich unangetastet (Kommentare, Community, Chat)
})();
