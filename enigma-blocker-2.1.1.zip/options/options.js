function setStatus(text, kind) {
  const el = document.getElementById("status");
  el.textContent = text;
  el.className = kind || "";
}

async function load() {
  const state = await browser.runtime.sendMessage({ type: "getState" });
  const s = state.settings;
  const fs = state.filterStats || {};

  document.getElementById("enabled").checked = !!s.enabled;
  document.getElementById("cosmeticFiltering").checked = !!s.cosmeticFiltering;
  document.getElementById("showBadge").checked = !!s.showBadge;

  const lists = s.enabledLists || {};
  document.querySelectorAll(".list-toggle").forEach((el) => {
    el.checked = lists[el.dataset.list] !== false;
  });

  document.getElementById("whitelist").value = (s.whitelist || []).join("\n");

  const cf = await browser.runtime.sendMessage({ type: "getCustomFilters" });
  document.getElementById("customFilters").value = cf.customFilters || "";

  document.getElementById("statNetwork").textContent = fs.network || 0;
  document.getElementById("statCosmetic").textContent =
    (fs.cosmeticGeneric || 0) + (fs.cosmeticHosts || 0);
  document.getElementById("statTotal").textContent = s.totalBlocked || 0;
}

function collect() {
  const enabledLists = {};
  document.querySelectorAll(".list-toggle").forEach((el) => {
    enabledLists[el.dataset.list] = el.checked;
  });

  const whitelist = document
    .getElementById("whitelist")
    .value.split(/\r?\n/)
    .map((l) => l.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, ""))
    .filter(Boolean);

  return {
    enabled: document.getElementById("enabled").checked,
    cosmeticFiltering: document.getElementById("cosmeticFiltering").checked,
    showBadge: document.getElementById("showBadge").checked,
    enabledLists,
    whitelist,
    customFilters: document.getElementById("customFilters").value,
  };
}

document.getElementById("btnSave").addEventListener("click", async () => {
  setStatus("Speichern…");
  try {
    const settings = collect();
    await browser.runtime.sendMessage({
      type: "updateSettings",
      settings,
      reloadFilters: true,
    });
    await load();
    setStatus("Gespeichert & Filter neu geladen.", "ok");
  } catch (e) {
    setStatus("Fehler: " + e.message, "err");
  }
});

document.getElementById("btnReload").addEventListener("click", async () => {
  setStatus("Filter werden geladen…");
  await browser.runtime.sendMessage({ type: "reloadFilters" });
  await load();
  setStatus("Filter neu geladen.", "ok");
});

document.getElementById("btnResetStats").addEventListener("click", async () => {
  if (!confirm("Statistik wirklich auf 0 setzen?")) return;
  await browser.runtime.sendMessage({ type: "resetStats" });
  await load();
  setStatus("Statistik zurückgesetzt.", "ok");
});

document.getElementById("btnExport").addEventListener("click", async () => {
  const settings = collect();
  const blob = new Blob([JSON.stringify({ enigmaBlocker: 2, settings }, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "enigma-blocker-settings.json";
  a.click();
  URL.revokeObjectURL(url);
  setStatus("Export gestartet.", "ok");
});

document.getElementById("btnImport").addEventListener("click", () => {
  document.getElementById("importFile").click();
});

document.getElementById("importFile").addEventListener("change", async (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const settings = data.settings || data;
    if (settings.customFilters != null) {
      document.getElementById("customFilters").value = settings.customFilters;
    }
    if (Array.isArray(settings.whitelist)) {
      document.getElementById("whitelist").value = settings.whitelist.join("\n");
    }
    if (settings.enabled != null) document.getElementById("enabled").checked = settings.enabled;
    if (settings.cosmeticFiltering != null)
      document.getElementById("cosmeticFiltering").checked = settings.cosmeticFiltering;
    if (settings.showBadge != null)
      document.getElementById("showBadge").checked = settings.showBadge;
    if (settings.enabledLists) {
      document.querySelectorAll(".list-toggle").forEach((el) => {
        if (settings.enabledLists[el.dataset.list] != null) {
          el.checked = !!settings.enabledLists[el.dataset.list];
        }
      });
    }
    setStatus("Import geladen – bitte „Speichern & anwenden“ klicken.", "ok");
  } catch (err) {
    setStatus("Import fehlgeschlagen: " + err.message, "err");
  }
  e.target.value = "";
});

load();
