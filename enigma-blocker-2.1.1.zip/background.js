/**
 * Enigma Blocker – Background (Firefox MV2)
 * Network blocking, stats, whitelist, settings sync
 */

const DEFAULT_SETTINGS = {
  enabled: true,
  blockAds: true,
  blockTrackers: true,
  blockMalware: true,
  cosmeticFiltering: true,
  showBadge: true,
  notifications: false,
  whitelist: [], // hostnames
  customFilters: "",
  enabledLists: {
    ads: true,
    trackers: true,
    malware: true,
    annoyances: true,
    de: true,
    youtube: true,
  },
  totalBlocked: 0,
  blockedToday: 0,
  todayDate: "",
};

let settings = { ...DEFAULT_SETTINGS };
let tabBlocked = new Map(); // tabId -> count
let ready = false;

const listUrls = {
  // Bundled local lists (always available offline)
  ads: "rules/ads.txt",
  trackers: "rules/trackers.txt",
  malware: "rules/malware.txt",
  annoyances: "rules/annoyances.txt",
  de: "rules/de.txt",
  youtube: "rules/youtube.txt",
};

// ── Storage ──────────────────────────────────────────────

async function loadSettings() {
  const data = await browser.storage.local.get(DEFAULT_SETTINGS);
  settings = { ...DEFAULT_SETTINGS, ...data };
  const today = new Date().toISOString().slice(0, 10);
  if (settings.todayDate !== today) {
    settings.blockedToday = 0;
    settings.todayDate = today;
    await browser.storage.local.set({
      blockedToday: 0,
      todayDate: today,
    });
  }
}

async function saveSettings(partial) {
  settings = { ...settings, ...partial };
  await browser.storage.local.set(partial);
}

// ── Filter lists ─────────────────────────────────────────

async function loadFilters() {
  FilterEngine.reset();

  // merge list flags so new lists (e.g. youtube) default to on
  settings.enabledLists = {
    ...DEFAULT_SETTINGS.enabledLists,
    ...(settings.enabledLists || {}),
  };

  const keys = Object.keys(listUrls);
  for (const key of keys) {
    if (settings.enabledLists[key] === false) continue;
    try {
      const url = browser.runtime.getURL(listUrls[key]);
      const res = await fetch(url);
      const text = await res.text();
      FilterEngine.addLines(text);
    } catch (e) {
      console.warn("[Enigma] list load failed:", key, e);
    }
  }

  if (settings.customFilters) {
    FilterEngine.addLines(settings.customFilters);
  }

  console.log("[Enigma] filters loaded", FilterEngine.stats());
  ready = true;
}

// ── Helpers ──────────────────────────────────────────────

function getHostname(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (_) {
    return "";
  }
}

function isWhitelisted(host) {
  if (!host) return false;
  return settings.whitelist.some(
    (w) => host === w || host.endsWith("." + w)
  );
}

function isPageWhitelisted(pageUrl) {
  return isWhitelisted(getHostname(pageUrl));
}

async function getTabUrl(tabId) {
  try {
    const tab = await browser.tabs.get(tabId);
    return tab.url || "";
  } catch (_) {
    return "";
  }
}

// ── Badge ────────────────────────────────────────────────

function updateBadge(tabId) {
  if (!settings.showBadge) {
    browser.browserAction.setBadgeText({ text: "", tabId });
    return;
  }
  const n = tabBlocked.get(tabId) || 0;
  const text = n > 999 ? "999+" : n > 0 ? String(n) : "";
  browser.browserAction.setBadgeText({ text, tabId });
  browser.browserAction.setBadgeBackgroundColor({
    color: settings.enabled ? "#00e676" : "#666666",
    tabId,
  });
}

function bumpStats(tabId) {
  settings.totalBlocked = (settings.totalBlocked || 0) + 1;
  settings.blockedToday = (settings.blockedToday || 0) + 1;
  // throttle storage writes
  if (settings.totalBlocked % 10 === 0) {
    browser.storage.local.set({
      totalBlocked: settings.totalBlocked,
      blockedToday: settings.blockedToday,
    });
  }
  if (tabId >= 0) {
    tabBlocked.set(tabId, (tabBlocked.get(tabId) || 0) + 1);
    updateBadge(tabId);
  }
}

// ── Request blocking ─────────────────────────────────────

function onBeforeRequest(details) {
  if (!ready || !settings.enabled) return {};

  // never touch extension pages
  if (details.url.startsWith("moz-extension://")) return {};

  // main frames only blocked if malware list hits (rare); skip by default for navigation
  if (details.type === "main_frame") return {};

  let pageHost = "";
  if (details.originUrl) {
    pageHost = getHostname(details.originUrl);
  } else if (details.documentUrl) {
    pageHost = getHostname(details.documentUrl);
  }

  if (pageHost && isWhitelisted(pageHost)) return {};

  // feature toggles – coarse: if ads off, only trackers/malware rules still apply
  // engine has all rules mixed; we rely on list toggles at load time
  const result = FilterEngine.matchRequest({
    url: details.url,
    type: details.type,
    pageHost,
  });

  if (result.block) {
    bumpStats(details.tabId);
    return { cancel: true };
  }
  return {};
}

// ── Messages ─────────────────────────────────────────────

browser.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || !msg.type) return;

  switch (msg.type) {
    case "getState": {
      const tabId = msg.tabId;
      return Promise.resolve({
        settings: {
          enabled: settings.enabled,
          blockAds: settings.blockAds,
          blockTrackers: settings.blockTrackers,
          blockMalware: settings.blockMalware,
          cosmeticFiltering: settings.cosmeticFiltering,
          showBadge: settings.showBadge,
          whitelist: settings.whitelist,
          totalBlocked: settings.totalBlocked,
          blockedToday: settings.blockedToday,
          enabledLists: settings.enabledLists,
        },
        tabBlocked: tabId != null ? tabBlocked.get(tabId) || 0 : 0,
        filterStats: FilterEngine.stats(),
      });
    }

    case "getCosmetic": {
      if (!settings.enabled || !settings.cosmeticFiltering) {
        return Promise.resolve({ selectors: [] });
      }
      const host = msg.hostname || "";
      if (isWhitelisted(host)) return Promise.resolve({ selectors: [] });
      return Promise.resolve({
        selectors: FilterEngine.getCosmeticSelectors(host),
      });
    }

    case "setEnabled":
      return saveSettings({ enabled: !!msg.value }).then(() => {
        refreshAllBadges();
        return { ok: true };
      });

    case "toggleWhitelist": {
      const host = (msg.host || "").toLowerCase();
      if (!host) return Promise.resolve({ ok: false });
      let list = [...settings.whitelist];
      const idx = list.indexOf(host);
      if (idx === -1) list.push(host);
      else list.splice(idx, 1);
      return saveSettings({ whitelist: list }).then(() => ({
        ok: true,
        whitelisted: idx === -1,
        whitelist: list,
      }));
    }

    case "updateSettings":
      return saveSettings(msg.settings || {}).then(async () => {
        if (msg.reloadFilters) await loadFilters();
        return { ok: true, settings };
      });

    case "reloadFilters":
      return loadFilters().then(() => ({
        ok: true,
        filterStats: FilterEngine.stats(),
      }));

    case "resetStats":
      return saveSettings({ totalBlocked: 0, blockedToday: 0 }).then(() => ({
        ok: true,
      }));

    case "getCustomFilters":
      return Promise.resolve({ customFilters: settings.customFilters || "" });

    case "reportBlocked":
      // content script cosmetic count (optional)
      if (sender.tab && sender.tab.id >= 0) {
        bumpStats(sender.tab.id);
      }
      return Promise.resolve({ ok: true });

    default:
      return Promise.resolve({ ok: false });
  }
});

function refreshAllBadges() {
  browser.tabs.query({}).then((tabs) => {
    for (const t of tabs) updateBadge(t.id);
  });
}

// ── Tab lifecycle ────────────────────────────────────────

browser.tabs.onRemoved.addListener((tabId) => {
  tabBlocked.delete(tabId);
});

browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading" && changeInfo.url) {
    tabBlocked.set(tabId, 0);
    updateBadge(tabId);
  }
});

// ── Context menu ─────────────────────────────────────────

function setupContextMenus() {
  browser.contextMenus.removeAll().then(() => {
    browser.contextMenus.create({
      id: "enigma-toggle-site",
      title: "Enigma: Seite (de)aktivieren",
      contexts: ["page", "browser_action"],
    });
    browser.contextMenus.create({
      id: "enigma-block-element",
      title: "Enigma: Element ausblenden…",
      contexts: ["all"],
    });
    browser.contextMenus.create({
      id: "enigma-options",
      title: "Enigma: Einstellungen",
      contexts: ["browser_action"],
    });
  });
}

browser.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === "enigma-options") {
    browser.runtime.openOptionsPage();
    return;
  }
  if (info.menuItemId === "enigma-toggle-site" && tab && tab.url) {
    const host = getHostname(tab.url);
    if (!host) return;
    let list = [...settings.whitelist];
    const idx = list.indexOf(host);
    if (idx === -1) list.push(host);
    else list.splice(idx, 1);
    await saveSettings({ whitelist: list });
    browser.tabs.reload(tab.id);
  }
  if (info.menuItemId === "enigma-block-element" && tab) {
    browser.tabs.sendMessage(tab.id, { type: "startPicker" }).catch(() => {});
  }
});

// ── Init ─────────────────────────────────────────────────

browser.webRequest.onBeforeRequest.addListener(
  onBeforeRequest,
  { urls: ["<all_urls>"] },
  ["blocking"]
);

(async function init() {
  await loadSettings();
  await loadFilters();
  setupContextMenus();
  browser.browserAction.setBadgeBackgroundColor({ color: "#00e676" });
  console.log("[Enigma Blocker] ready");
})();
