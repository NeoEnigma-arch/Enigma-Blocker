async function getActiveTab() {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function hostFromUrl(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (_) {
    return "";
  }
}

function formatNum(n) {
  n = n || 0;
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "k";
  return String(n);
}

async function refresh() {
  const tab = await getActiveTab();
  const tabId = tab ? tab.id : null;
  const host = tab ? hostFromUrl(tab.url) : "";

  const state = await browser.runtime.sendMessage({ type: "getState", tabId });
  const s = state.settings;

  const enabledEl = document.getElementById("toggleEnabled");
  enabledEl.checked = !!s.enabled;
  document.body.classList.toggle("disabled", !s.enabled);

  document.getElementById("tabBlocked").textContent = formatNum(state.tabBlocked);
  document.getElementById("todayBlocked").textContent = formatNum(s.blockedToday);
  document.getElementById("totalBlocked").textContent = formatNum(s.totalBlocked);

  document.getElementById("siteHost").textContent = host || "(keine Webseite)";

  const whitelisted = host && (s.whitelist || []).includes(host);
  const status = document.getElementById("siteStatus");
  const btnW = document.getElementById("btnWhitelist");

  if (!s.enabled) {
    status.textContent = "global deaktiviert";
    status.className = "site-status disabled";
  } else if (whitelisted) {
    status.textContent = "auf Whitelist – nicht geschützt";
    status.className = "site-status off";
  } else {
    status.textContent = "geschützt";
    status.className = "site-status";
  }

  btnW.textContent = whitelisted ? "Entfernen" : "Whitelist";
  btnW.classList.toggle("active", !!whitelisted);
  btnW.disabled = !host;

  const fs = state.filterStats || {};
  document.getElementById("filterMeta").textContent =
    `Filter: ${fs.network || 0} Netz · ${fs.cosmeticGeneric || 0}+ kosmetisch`;
}

document.getElementById("toggleEnabled").addEventListener("change", async (e) => {
  await browser.runtime.sendMessage({ type: "setEnabled", value: e.target.checked });
  refresh();
});

document.getElementById("btnWhitelist").addEventListener("click", async () => {
  const tab = await getActiveTab();
  const host = tab ? hostFromUrl(tab.url) : "";
  if (!host) return;
  await browser.runtime.sendMessage({ type: "toggleWhitelist", host });
  if (tab && tab.id) browser.tabs.reload(tab.id);
  refresh();
});

document.getElementById("btnPicker").addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!tab || !tab.id) return;
  try {
    await browser.tabs.sendMessage(tab.id, { type: "startPicker" });
    window.close();
  } catch (_) {
    alert("Element-Picker ist auf dieser Seite nicht verfügbar (z. B. about: pages).");
  }
});

document.getElementById("btnReload").addEventListener("click", async () => {
  const btn = document.getElementById("btnReload");
  btn.textContent = "Lädt…";
  await browser.runtime.sendMessage({ type: "reloadFilters" });
  btn.textContent = "Filter neu laden";
  refresh();
});

document.getElementById("btnOptions").addEventListener("click", () => {
  browser.runtime.openOptionsPage();
});

refresh();
